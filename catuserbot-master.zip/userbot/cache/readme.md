To store cache file of CatUserbot
